package model;

public class CartaoException extends RuntimeException {
    public CartaoException(String mensagem) {
        super(mensagem);
    }
}